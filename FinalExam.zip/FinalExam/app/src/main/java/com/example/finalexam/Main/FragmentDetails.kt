package com.example.finalexam.Main


import androidx.fragment.app.Fragment
import com.example.finalexam.R

class FragmentDetails : Fragment(R.layout.fragment_details) {

}